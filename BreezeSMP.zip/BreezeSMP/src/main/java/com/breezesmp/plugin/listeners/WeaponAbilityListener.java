package com.breezesmp.plugin.listeners;

import com.breezesmp.plugin.BreezeSMP;
import com.breezesmp.plugin.items.CooldownManager;
import com.breezesmp.plugin.items.CustomItems;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.WindCharge;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.block.Action;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class WeaponAbilityListener implements Listener {

    private final BreezeSMP plugin;
    private final CustomItems customItems;
    private final CooldownManager cooldownManager;

    // Tracks WindCharge entities we spawned for the ability, so we can apply
    // custom damage/launch instead of vanilla wind charge knockback.
    private final Set<UUID> customWindCharges = new HashSet<>();

    private static final double WIND_CHARGE_DAMAGE = 8.0;   // 4 hearts = 8 damage points
    private static final double OBLIVION_DAMAGE = 13.0;     // 6.5 hearts = 13 damage points
    private static final double OBLIVION_MAX_DISTANCE = 20.0;

    public WeaponAbilityListener(BreezeSMP plugin, CustomItems customItems, CooldownManager cooldownManager) {
        this.plugin = plugin;
        this.customItems = customItems;
        this.cooldownManager = cooldownManager;
    }

    @EventHandler(ignoreCancelled = false)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        if (!player.isSneaking()) return;

        // Only trigger once per interaction (avoid double fire for main+off hand)
        if (event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;

        var item = event.getItem();
        if (item == null) return;

        if (customItems.isWindChargeRod(item)) {
            event.setCancelled(true);
            handleWindChargeRod(player);
        } else if (customItems.isOblivionSword(item)) {
            event.setCancelled(true);
            handleOblivionSword(player);
        }
    }

    private void handleWindChargeRod(Player player) {
        UUID uuid = player.getUniqueId();
        if (cooldownManager.isOnWindChargeCooldown(uuid)) {
            long secs = cooldownManager.getWindChargeRemainingSeconds(uuid);
            player.sendActionBar(Component.text("Wind Charge Rod on cooldown: " + secs + "s", NamedTextColor.RED));
            return;
        }

        cooldownManager.setWindChargeCooldown(uuid);

        Location eyeLoc = player.getEyeLocation();
        Vector direction = eyeLoc.getDirection();

        // Spawn the wind charge slightly in front of the player so it doesn't
        // immediately collide with them.
        Location spawnLoc = eyeLoc.clone().add(direction.clone().multiply(1.0));

        WindCharge windCharge = player.getWorld().spawn(spawnLoc, WindCharge.class, wc -> {
            wc.setShooter(player);
            wc.setVelocity(direction.clone().multiply(2.2));
        });
        // Make it visually "big" via a persistent scale-ish effect isn't natively
        // supported on WindCharge, so we mark it and pair it with particles instead.
        customWindCharges.add(windCharge.getUniqueId());

        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BREEZE_SHOOT, 1.5f, 0.7f);
        player.getWorld().spawnParticle(Particle.GUST_EMITTER_LARGE, spawnLoc, 1);

        // Safety cleanup in case it never collides with anything (e.g. flies into void)
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (windCharge.isValid()) {
                customWindCharges.remove(windCharge.getUniqueId());
                windCharge.remove();
            }
        }, 200L); // 10 seconds
    }

    @EventHandler
    public void onExplosionPrime(ExplosionPrimeEvent event) {
        // Prevent our custom wind charges from breaking blocks / vanilla explosion behavior
        if (customWindCharges.contains(event.getEntity().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    // Wind charges don't break blocks by default, so EntityExplodeEvent normally
    // won't fire for them — but we guard it anyway in case that ever changes.
    @EventHandler
    public void onEntityExplode(EntityExplodeEvent event) {
        if (customWindCharges.contains(event.getEntity().getUniqueId())) {
            event.setCancelled(true);
            event.blockList().clear();
        }
    }

    // We cancel the wind charge's vanilla explosion (via ExplosionPrimeEvent /
    // EntityExplodeEvent above) and instead apply damage and launch velocity
    // manually here, on impact, giving us full control over the "big wind
    // charge" damage and launch values regardless of vanilla explosion behavior.
    @EventHandler
    public void onProjectileHit(org.bukkit.event.entity.ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof WindCharge windCharge)) return;
        if (!customWindCharges.contains(windCharge.getUniqueId())) return;

        customWindCharges.remove(windCharge.getUniqueId());

        Location impact = windCharge.getLocation();
        playImpactEffects(impact);

        if (!(windCharge.getShooter() instanceof Player shooter)) {
            windCharge.remove();
            return;
        }

        // Find nearby living entities to apply the "big" wind charge effect to
        for (Entity nearby : impact.getWorld().getNearbyEntities(impact, 3.5, 3.5, 3.5)) {
            if (!(nearby instanceof LivingEntity living)) continue;
            if (living.getUniqueId().equals(shooter.getUniqueId())) continue;

            living.damage(WIND_CHARGE_DAMAGE, shooter);
            Vector launch = new Vector(
                    (Math.random() - 0.5) * 0.3,
                    2.2, // strong upward velocity, roughly 20-30 blocks with gravity/drag
                    (Math.random() - 0.5) * 0.3
            );
            living.setVelocity(launch);
            living.setFallDistance(0f); // fall damage will still apply naturally on landing
        }

        windCharge.remove();
    }

    private void playImpactEffects(Location impact) {
        impact.getWorld().spawnParticle(Particle.GUST_EMITTER_LARGE, impact, 3, 0.5, 0.5, 0.5, 0);
        impact.getWorld().spawnParticle(Particle.CLOUD, impact, 40, 1.2, 1.2, 1.2, 0.05);
        impact.getWorld().playSound(impact, Sound.ENTITY_BREEZE_WIND_BURST, 2.0f, 0.8f);
    }

    private void handleOblivionSword(Player player) {
        UUID uuid = player.getUniqueId();
        if (cooldownManager.isOnOblivionCooldown(uuid)) {
            long secs = cooldownManager.getOblivionRemainingSeconds(uuid);
            player.sendActionBar(Component.text("Oblivion Sword on cooldown: " + secs + "s", NamedTextColor.RED));
            return;
        }

        LivingEntity target = getTargetEntity(player, OBLIVION_MAX_DISTANCE);
        if (target == null) {
            player.sendActionBar(Component.text("No target in range.", NamedTextColor.RED));
            return;
        }

        cooldownManager.setOblivionCooldown(uuid);

        Location start = player.getLocation();

        player.getWorld().playSound(start, Sound.ENTITY_ENDER_DRAGON_FLAP, 1.2f, 1.4f);
        player.getWorld().spawnParticle(Particle.SWEEP_ATTACK, start.clone().add(0, 1, 0), 5);

        // Launch the player up first
        Vector up = new Vector(0, 1.1, 0);
        player.setVelocity(up);

        // Delay the lunge slightly so the "launch into air" reads first, then lunge at target
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline() || !target.isValid()) return;

            Location playerLoc = player.getLocation();
            Location freshTargetLoc = target.getLocation();
            Vector toTarget = freshTargetLoc.toVector().subtract(playerLoc.toVector());
            double horizontalDist = Math.sqrt(toTarget.getX() * toTarget.getX() + toTarget.getZ() * toTarget.getZ());

            Vector lunge = toTarget.clone();
            if (horizontalDist > 0.001) {
                lunge.setX(toTarget.getX() / horizontalDist * 1.8);
                lunge.setZ(toTarget.getZ() / horizontalDist * 1.8);
            }
            lunge.setY(Math.max(0.4, toTarget.getY() * 0.3));

            player.setVelocity(lunge);
            player.getWorld().spawnParticle(Particle.CRIT, playerLoc, 20, 0.3, 0.3, 0.3, 0.2);

            // Apply the strike shortly after the lunge starts, once close
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline() || !target.isValid()) return;
                if (player.getLocation().distance(target.getLocation()) <= 4.0) {
                    target.damage(OBLIVION_DAMAGE, player);
                    target.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, target.getLocation().add(0, 1, 0), 10);
                    target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.5f, 1.0f);
                }
            }, 6L);
        }, 4L);
    }

    private LivingEntity getTargetEntity(Player player, double maxDistance) {
        RayTraceResult result = player.getWorld().rayTraceEntities(
                player.getEyeLocation(),
                player.getEyeLocation().getDirection(),
                maxDistance,
                0.4,
                entity -> entity instanceof LivingEntity && !entity.equals(player)
        );
        if (result == null || result.getHitEntity() == null) return null;
        return (LivingEntity) result.getHitEntity();
    }
}
