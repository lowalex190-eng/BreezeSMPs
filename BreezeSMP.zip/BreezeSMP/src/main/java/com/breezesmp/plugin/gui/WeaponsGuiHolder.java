package com.breezesmp.plugin.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/**
 * Marker holder so we can reliably identify our custom GUI in InventoryClickEvent
 * without relying on comparing title text (which requires extra Adventure
 * serializer dependencies and is fragile against title changes).
 */
public class WeaponsGuiHolder implements InventoryHolder {

    private Inventory inventory;

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
