package com.breezesmp.plugin.gui;

import com.breezesmp.plugin.BreezeSMP;
import com.breezesmp.plugin.items.CustomItems;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class WeaponsGui implements Listener {

    private static final int WIND_CHARGE_SLOT = 2;
    private static final int OBLIVION_SLOT = 6;

    private final BreezeSMP plugin;
    private final CustomItems customItems;

    public WeaponsGui(BreezeSMP plugin, CustomItems customItems) {
        this.plugin = plugin;
        this.customItems = customItems;
    }

    public void open(Player player) {
        WeaponsGuiHolder holder = new WeaponsGuiHolder();
        Inventory inv = plugin.getServer().createInventory(holder, 9,
                Component.text("BreezeSMP Weapons", NamedTextColor.DARK_AQUA)
                        .decoration(TextDecoration.ITALIC, false));
        holder.setInventory(inv);

        inv.setItem(WIND_CHARGE_SLOT, customItems.createWindChargeRod());
        inv.setItem(OBLIVION_SLOT, customItems.createOblivionSword());

        player.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        InventoryHolder topHolder = event.getView().getTopInventory().getHolder();
        if (!(topHolder instanceof WeaponsGuiHolder)) return;

        event.setCancelled(true);

        if (event.getClickedInventory() == null
                || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        if (!(event.getWhoClicked() instanceof Player player)) return;

        String id = customItems.getCustomId(clicked);
        if (id == null) return;

        ItemStack give;
        if (CustomItems.WIND_CHARGE_ROD_ID.equals(id)) {
            give = customItems.createWindChargeRod();
        } else if (CustomItems.OBLIVION_SWORD_ID.equals(id)) {
            give = customItems.createOblivionSword();
        } else {
            return;
        }

        player.getInventory().addItem(give);
        player.closeInventory();
        player.sendMessage(Component.text("You received the weapon!", NamedTextColor.GREEN));
    }
}
