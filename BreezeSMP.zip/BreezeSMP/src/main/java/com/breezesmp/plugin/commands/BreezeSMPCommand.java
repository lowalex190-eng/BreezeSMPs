package com.breezesmp.plugin.commands;

import com.breezesmp.plugin.BreezeSMP;
import com.breezesmp.plugin.gui.WeaponsGui;
import com.breezesmp.plugin.items.CustomItems;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class BreezeSMPCommand implements CommandExecutor, TabCompleter {

    private final BreezeSMP plugin;
    private final CustomItems customItems;
    private final WeaponsGui weaponsGui;

    public BreezeSMPCommand(BreezeSMP plugin, CustomItems customItems, WeaponsGui weaponsGui) {
        this.plugin = plugin;
        this.customItems = customItems;
        this.weaponsGui = weaponsGui;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // plugin.yml also restricts this via the "permission" field, but we
        // double-check here so the message is clear and consistent.
        if (!sender.hasPermission("breezesmp.admin")) {
            sender.sendMessage(Component.text("You do not have permission to use this command.", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(Component.text("Only players can open the weapons menu.", NamedTextColor.RED));
                return true;
            }
            weaponsGui.open(player);
            return true;
        }

        if (args[0].equalsIgnoreCase("give")) {
            return handleGive(sender, args);
        }

        sendUsage(sender);
        return true;
    }

    private boolean handleGive(CommandSender sender, String[] args) {
        // Supported forms:
        // /breezesmp give <windchargerod|oblivionsword>            (self, sender must be a player)
        // /breezesmp give <player> <windchargerod|oblivionsword>   (give to another player)
        if (args.length < 2) {
            sendUsage(sender);
            return true;
        }

        Player target;
        String weaponArg;

        if (args.length >= 3) {
            target = plugin.getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(Component.text("Player not found: " + args[1], NamedTextColor.RED));
                return true;
            }
            weaponArg = args[2];
        } else {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(Component.text("Console must specify a player: /breezesmp give <player> <weapon>", NamedTextColor.RED));
                return true;
            }
            target = player;
            weaponArg = args[1];
        }

        ItemStack item = resolveWeapon(weaponArg);
        if (item == null) {
            sender.sendMessage(Component.text("Unknown weapon. Use 'windchargerod' or 'oblivionsword'.", NamedTextColor.RED));
            return true;
        }

        target.getInventory().addItem(item);
        sender.sendMessage(Component.text("Gave " + itemFriendlyName(weaponArg) + " to " + target.getName() + ".", NamedTextColor.GREEN));
        if (!sender.equals(target)) {
            target.sendMessage(Component.text("You received the " + itemFriendlyName(weaponArg) + "!", NamedTextColor.GREEN));
        }
        return true;
    }

    private ItemStack resolveWeapon(String arg) {
        String normalized = arg.replace(" ", "").replace("_", "").toLowerCase();
        return switch (normalized) {
            case "windchargerod" -> customItems.createWindChargeRod();
            case "oblivionsword" -> customItems.createOblivionSword();
            default -> null;
        };
    }

    private String itemFriendlyName(String arg) {
        String normalized = arg.replace(" ", "").replace("_", "").toLowerCase();
        return switch (normalized) {
            case "windchargerod" -> "Wind Charge Rod";
            case "oblivionsword" -> "Oblivion Sword";
            default -> arg;
        };
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(Component.text("Usage:", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("/breezesmp - open the weapons menu", NamedTextColor.GRAY));
        sender.sendMessage(Component.text("/breezesmp give <windchargerod|oblivionsword>", NamedTextColor.GRAY));
        sender.sendMessage(Component.text("/breezesmp give <player> <windchargerod|oblivionsword>", NamedTextColor.GRAY));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> options = new ArrayList<>();
        if (!sender.hasPermission("breezesmp.admin")) return options;

        if (args.length == 1) {
            options.add("give");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            options.add("windchargerod");
            options.add("oblivionsword");
            for (Player p : plugin.getServer().getOnlinePlayers()) {
                options.add(p.getName());
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            options.add("windchargerod");
            options.add("oblivionsword");
        }
        return options;
    }
}
