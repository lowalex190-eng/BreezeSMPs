package com.breezesmp.plugin.items;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {

    private final Map<UUID, Long> windChargeRodCooldowns = new HashMap<>();
    private final Map<UUID, Long> oblivionSwordCooldowns = new HashMap<>();

    public static final long WIND_CHARGE_ROD_COOLDOWN_MS = 50_000L;
    public static final long OBLIVION_SWORD_COOLDOWN_MS = 40_000L;

    public boolean isOnWindChargeCooldown(UUID uuid) {
        return remainingMs(windChargeRodCooldowns, uuid) > 0;
    }

    public boolean isOnOblivionCooldown(UUID uuid) {
        return remainingMs(oblivionSwordCooldowns, uuid) > 0;
    }

    public long getWindChargeRemainingSeconds(UUID uuid) {
        return (remainingMs(windChargeRodCooldowns, uuid) + 999) / 1000;
    }

    public long getOblivionRemainingSeconds(UUID uuid) {
        return (remainingMs(oblivionSwordCooldowns, uuid) + 999) / 1000;
    }

    public void setWindChargeCooldown(UUID uuid) {
        windChargeRodCooldowns.put(uuid, System.currentTimeMillis() + WIND_CHARGE_ROD_COOLDOWN_MS);
    }

    public void setOblivionCooldown(UUID uuid) {
        oblivionSwordCooldowns.put(uuid, System.currentTimeMillis() + OBLIVION_SWORD_COOLDOWN_MS);
    }

    private long remainingMs(Map<UUID, Long> map, UUID uuid) {
        Long expiry = map.get(uuid);
        if (expiry == null) return 0;
        long remaining = expiry - System.currentTimeMillis();
        return Math.max(remaining, 0);
    }
}
