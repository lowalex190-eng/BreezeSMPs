package com.breezesmp.plugin.items;

import com.breezesmp.plugin.BreezeSMP;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.RecipeChoice;

public class RecipeRegistrar {

    private final BreezeSMP plugin;
    private final CustomItems customItems;

    public RecipeRegistrar(BreezeSMP plugin, CustomItems customItems) {
        this.plugin = plugin;
        this.customItems = customItems;
    }

    public void registerRecipes() {
        registerWindChargeRodRecipe();
        registerOblivionSwordRecipe();
    }

    private void registerWindChargeRodRecipe() {
        // A vanilla crafting grid only has 9 slots, so "10 breeze rods + 5 enchanted
        // golden apples" (15 items) can't literally fit. We preserve the intended
        // design (sides = breeze rods, middle = enchanted golden apples) scaled to
        // fit the 3x3 grid: 6 breeze rods on the left/right columns, 3 enchanted
        // golden apples in the middle column.
        ItemStack result = customItems.createWindChargeRod();
        NamespacedKey key = new NamespacedKey(plugin, "wind_charge_rod");
        ShapedRecipe recipe = new ShapedRecipe(key, result);

        recipe.shape("BAB", "BAB", "BAB");
        recipe.setIngredient('B', new RecipeChoice.MaterialChoice(Material.BREEZE_ROD));
        recipe.setIngredient('A', new RecipeChoice.MaterialChoice(Material.ENCHANTED_GOLDEN_APPLE));

        plugin.getServer().addRecipe(recipe);
    }

    private void registerOblivionSwordRecipe() {
        // 2 diamond swords on the sides, 1 netherite sword in the middle, all unenchanted.
        ItemStack result = customItems.createOblivionSword();
        NamespacedKey key = new NamespacedKey(plugin, "oblivion_sword");
        ShapedRecipe recipe = new ShapedRecipe(key, result);

        // "2 diamond swords on the sides and 1 netherite sword in the middle"
        // Note: MaterialChoice matches by material only, not enchantment state.
        // Vanilla shaped recipes have no built-in way to require "unenchanted" —
        // enchanted diamond/netherite swords will also satisfy this recipe.
        recipe.shape("DND");
        recipe.setIngredient('D', new RecipeChoice.MaterialChoice(Material.DIAMOND_SWORD));
        recipe.setIngredient('N', new RecipeChoice.MaterialChoice(Material.NETHERITE_SWORD));

        plugin.getServer().addRecipe(recipe);
    }
}
