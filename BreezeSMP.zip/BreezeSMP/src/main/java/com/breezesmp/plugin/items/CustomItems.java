package com.breezesmp.plugin.items;

import com.breezesmp.plugin.BreezeSMP;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public class CustomItems {

    public static final String WIND_CHARGE_ROD_ID = "wind_charge_rod";
    public static final String OBLIVION_SWORD_ID = "oblivion_sword";

    private final BreezeSMP plugin;
    private final NamespacedKey itemIdKey;

    public CustomItems(BreezeSMP plugin) {
        this.plugin = plugin;
        this.itemIdKey = new NamespacedKey(plugin, "breezesmp_item_id");
    }

    public NamespacedKey getItemIdKey() {
        return itemIdKey;
    }

    public ItemStack createWindChargeRod() {
        // Texture request: "normal breeze rod but with the wind charge rod name"
        // Breeze Rod is the item obtained from breezes (Material.BREEZE_ROD)
        ItemStack item = new ItemStack(Material.BREEZE_ROD);
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text("Wind Charge Rod", NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));

        meta.lore(List.of(
                Component.text("Shift + Right-Click to summon", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("a massive Wind Charge at your target.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Component.text("Deals 4 hearts & launches target skyward", NamedTextColor.DARK_AQUA)
                        .decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Component.text("Cooldown: 50s", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false)
        ));

        meta.getPersistentDataContainer().set(itemIdKey, PersistentDataType.STRING, WIND_CHARGE_ROD_ID);
        meta.setUnbreakable(true);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack createOblivionSword() {
        // Texture request: "neth sword texture" -> Netherite Sword material/model
        ItemStack item = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text("Oblivion Sword", NamedTextColor.DARK_RED)
                .decoration(TextDecoration.ITALIC, false));

        meta.lore(List.of(
                Component.text("Shift + Right-Click to lunge at", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("your target and strike them down.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Component.text("Deals 6.5 hearts", NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Component.text("Cooldown: 40s", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false)
        ));

        meta.getPersistentDataContainer().set(itemIdKey, PersistentDataType.STRING, OBLIVION_SWORD_ID);
        meta.setUnbreakable(true);
        item.setItemMeta(meta);
        return item;
    }

    public String getCustomId(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        return meta.getPersistentDataContainer().get(itemIdKey, PersistentDataType.STRING);
    }

    public boolean isWindChargeRod(ItemStack item) {
        return WIND_CHARGE_ROD_ID.equals(getCustomId(item));
    }

    public boolean isOblivionSword(ItemStack item) {
        return OBLIVION_SWORD_ID.equals(getCustomId(item));
    }
}
